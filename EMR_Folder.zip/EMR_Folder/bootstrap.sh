#!/bin/bash
sudo pip3 install -U \
    matplotlib \
    pandas